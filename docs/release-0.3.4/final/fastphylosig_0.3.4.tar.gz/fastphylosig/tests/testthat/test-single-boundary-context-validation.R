.single_boundary_fixture <- function(n = 24L) {
  set.seed(20260904)
  tree <- ape::rtree(n)
  tree$node.label <- paste0("node", seq_len(tree$Nnode))
  trait <- stats::setNames(stats::rnorm(n), tree$tip.label)
  list(tree = tree, trait = trait)
}

.run_prepared_k <- function(ctx, trait) {
  fast_k(
    ctx,
    trait,
    test = FALSE,
    verbose = FALSE,
    progress = FALSE
  )
}

test_that("one prepared public call performs one complete fingerprint", {
  fixture <- .single_boundary_fixture()
  ctx <- prepare_tree(fixture$tree)
  original <- fastphylosig:::.tree_fingerprint
  calls <- new.env(parent = emptyenv())
  calls$n <- 0L
  testthat::local_mocked_bindings(
    .tree_fingerprint = function(tree, ...) {
      calls$n <- calls$n + 1L
      original(tree, ...)
    },
    .package = "fastphylosig"
  )

  invisible(.run_prepared_k(ctx, fixture$trait))
  expect_identical(calls$n, 1L)
  expect_null(attr(ctx, "fastphylosig_validation_capability", exact = TRUE))

  invisible(.run_prepared_k(ctx, fixture$trait))
  expect_identical(calls$n, 2L)
  expect_null(attr(ctx, "fastphylosig_validation_capability", exact = TRUE))
})

test_that("raw continuous analysis uses one preparation boundary", {
  fixture <- .single_boundary_fixture()
  originals <- lapply(
    c(".tree_fingerprint", ".inspect_tree_core", ".safe_canonicalize_core",
      ".canonical_tree_signature"),
    getFromNamespace,
    ns = "fastphylosig"
  )
  names(originals) <- c(
    ".tree_fingerprint", ".inspect_tree_core", ".safe_canonicalize_core",
    ".canonical_tree_signature"
  )
  calls <- new.env(parent = emptyenv())
  calls$fingerprint <- 0L
  calls$inspect <- 0L
  calls$canonicalize <- 0L
  calls$signature <- 0L

  testthat::local_mocked_bindings(
    .tree_fingerprint = function(tree, ...) {
      calls$fingerprint <- calls$fingerprint + 1L
      originals$.tree_fingerprint(tree, ...)
    },
    .inspect_tree_core = function(...) {
      calls$inspect <- calls$inspect + 1L
      originals$.inspect_tree_core(...)
    },
    .safe_canonicalize_core = function(...) {
      calls$canonicalize <- calls$canonicalize + 1L
      originals$.safe_canonicalize_core(...)
    },
    .canonical_tree_signature = function(...) {
      calls$signature <- calls$signature + 1L
      originals$.canonical_tree_signature(...)
    },
    .package = "fastphylosig"
  )

  invisible(fast_k(fixture$tree, fixture$trait, test = FALSE,
                   verbose = FALSE, progress = FALSE))
  expect_identical(calls$fingerprint, 1L)
  expect_identical(calls$inspect, 1L)
  expect_identical(calls$canonicalize, 1L)
  # Contract V2 derives canonical order from exact byte ranks and never calls
  # the retained V1 delimiter-based signature oracle in production.
  expect_identical(calls$signature, 0L)
})

test_that("each protected structural mutation is rejected on the next call", {
  fixture <- .single_boundary_fixture()
  mutations <- list(
    edge = function(ctx) {
      ctx$tree$edge[1L, 2L] <- ctx$tree$edge[2L, 2L]
      ctx
    },
    edge_length = function(ctx) {
      ctx$tree$edge.length[[1L]] <- ctx$tree$edge.length[[1L]] + 0.01
      ctx
    },
    tip_label = function(ctx) {
      ctx$tree$tip.label[[1L]] <- paste0(ctx$tree$tip.label[[1L]], "_changed")
      ctx
    },
    Nnode = function(ctx) {
      ctx$tree$Nnode <- as.integer(ctx$tree$Nnode + 1L)
      ctx
    }
  )

  for (name in names(mutations)) {
    ctx <- prepare_tree(fixture$tree)
    invisible(.run_prepared_k(ctx, fixture$trait))
    ctx <- mutations[[name]](ctx)
    expect_error(
      .run_prepared_k(ctx, fixture$trait),
      "prepared tree was modified after caching",
      info = name
    )
  }
})

test_that("non-computational node labels remain outside the fingerprint contract", {
  fixture <- .single_boundary_fixture()
  ctx <- prepare_tree(fixture$tree)
  before <- .run_prepared_k(ctx, fixture$trait)
  ctx$tree$node.label[[1L]] <- "metadata-only change"
  after <- .run_prepared_k(ctx, fixture$trait)

  expect_identical(unname(as.numeric(after)), unname(as.numeric(before)))
})
